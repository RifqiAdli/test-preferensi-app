<?php
// admin/dashboard.php
session_start();
require_once '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Fetch all responses with user information
$sql = "SELECT u.name, u.email, u.created_at, 
        GROUP_CONCAT(CONCAT(r.question_number, ':', r.answer) ORDER BY r.question_number) as answers
        FROM users u
        LEFT JOIN responses r ON u.id = r.user_id
        GROUP BY u.id
        ORDER BY u.created_at DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold">Hasil Tes Preferensi</h1>
                <a href="logout.php" 
                   class="bg-red-500 text-white py-2 px-4 rounded hover:bg-red-600">
                    Logout
                </a>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full table-auto">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="px-4 py-2 text-left">Nama</th>
                            <th class="px-4 py-2 text-left">Email</th>
                            <th class="px-4 py-2 text-left">Tanggal</th>
                            <th class="px-4 py-2 text-left">Jawaban</th>
                            <th class="px-4 py-2 text-left">Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr class="border-t">
                                <td class="px-4 py-2"><?= htmlspecialchars($row['name']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($row['email']) ?></td>
                                <td class="px-4 py-2">
                                    <?= date('d/m/Y H:i', strtotime($row['created_at'])) ?>
                                </td>
                                <td class="px-4 py-2">
                                    <?php
                                    $answers = explode(',', $row['answers']);
                                    foreach ($answers as $answer) {
                                        list($q, $a) = explode(':', $answer);
                                        echo "Q$q: $a &nbsp;";
                                    }
                                    ?>
                                </td>
                                <td class="px-4 py-2">
                                    <button onclick="showDetail('<?= htmlspecialchars($row['name']) ?>', '<?= $row['answers'] ?>')"
                                            class="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600">
                                        Lihat Detail
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Detail -->
    <div id="detailModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <div class="bg-white p-6 rounded-lg max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold" id="modalTitle"></h2>
                <button onclick="closeModal()" class="text-gray-500 hover:text-gray-700">
                    ✕
                </button>
            </div>
            <div id="modalContent" class="space-y-4"></div>
        </div>
    </div>

    <script>
    const questions = <?= json_encode(QUESTIONS) ?>;
    const options = <?= json_encode(OPTIONS) ?>;

    function showDetail(name, answersStr) {
        const modal = document.getElementById('detailModal');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');
        
        title.textContent = `Detail Jawaban - ${name}`;
        
        // Parse answers string into object
        const answers = {};
        answersStr.split(',').forEach(answer => {
            const [q, a] = answer.split(':');
            answers[q] = a;
        });
        
        // Calculate preferences
        let introvertScore = 0;
        let extrovertScore = 0;
        let analyticalScore = 0;
        let intuitiveScore = 0;
        
        // Create detailed content
        let html = '<div class="space-y-6">';
        
        // Detailed answers section
        html += '<div class="space-y-4">';
        html += '<h3 class="text-lg font-semibold">Jawaban Detail:</h3>';
        
        Object.entries(questions).forEach(([number, question]) => {
            const answer = answers[number] || '-';
            const chosenOption = answer !== '-' ? options[number][answer] : 'Tidak dijawab';
            
            // Calculate scores based on answers
            if (answer === 'A') {
                if ([2,3,5,8,16,17,18].includes(parseInt(number))) introvertScore++;
                if ([4,6,9,11,13,15,20].includes(parseInt(number))) analyticalScore++;
            } else if (answer === 'B') {
                if ([2,3,5,8,16,17,18].includes(parseInt(number))) extrovertScore++;
                if ([4,6,9,11,13,15,20].includes(parseInt(number))) intuitiveScore++;
            }
            
            html += `
                <div class="border-b pb-2">
                    <p class="font-medium">Pertanyaan ${number}:</p>
                    <p class="text-gray-600 ml-4">${question}</p>
                    <p class="ml-4">Jawaban: <span class="font-medium">${answer}. ${chosenOption}</span></p>
                </div>
            `;
        });
        html += '</div>';
        
        // Summary section
        html += '<div class="mt-6 p-4 bg-gray-50 rounded-lg">';
        html += '<h3 class="text-lg font-semibold mb-3">Ringkasan Preferensi:</h3>';
        
        // Introvert vs Extrovert
        const introExtroTotal = introvertScore + extrovertScore;
        const introvertPercentage = (introvertScore / introExtroTotal * 100).toFixed(1);
        const extrovertPercentage = (extrovertScore / introExtroTotal * 100).toFixed(1);
        
        // Analytical vs Intuitive
        const analIntTotal = analyticalScore + intuitiveScore;
        const analyticalPercentage = (analyticalScore / analIntTotal * 100).toFixed(1);
        const intuitivePercentage = (intuitiveScore / analIntTotal * 100).toFixed(1);
        
        html += `
            <div class="space-y-4">
                <div>
                    <p class="font-medium">Introvert vs Extrovert:</p>
                    <div class="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                        <div class="bg-blue-600 h-2.5 rounded-full" style="width: ${introvertPercentage}%"></div>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span>Introvert: ${introvertPercentage}%</span>
                        <span>Extrovert: ${extrovertPercentage}%</span>
                    </div>
                </div>
                
                <div>
                    <p class="font-medium">Analytical vs Intuitive:</p>
                    <div class="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                        <div class="bg-green-600 h-2.5 rounded-full" style="width: ${analyticalPercentage}%"></div>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span>Analytical: ${analyticalPercentage}%</span>
                        <span>Intuitive: ${intuitivePercentage}%</span>
                    </div>
                </div>
            </div>
        `;
        html += '</div>';
        
        html += '</div>';
        
        content.innerHTML = html;
        modal.classList.remove('hidden');
    }

    function closeModal() {
        const modal = document.getElementById('detailModal');
        modal.classList.add('hidden');
    }

    // Close modal when clicking outside
    document.getElementById('detailModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>
</body>
</html>